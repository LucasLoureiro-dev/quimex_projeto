<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Lembrete - Fábrica Coca Cola</title>

  <!-- fonte -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

  <!-- CSS -->
  <link rel="stylesheet" href="lembretecoca.css">
</head>

<body>

  <div class="page-bg">
    <div class="canvas">

      <header class="header">
        <div class="header-container">
          <div class="logo">
            <img src="https://upload.wikimedia.org/wikipedia/commons/c/ce/Coca-Cola_logo.svg" alt="Coca-Cola Logo">
          </div>

          <nav class="nav-menu">
            <ul>
              <li><a href="cocacola.html">Login</a></li>
              <li><a href="lembretecoca.html">Lembrete</a></li>
              <li><a href="#">Relatório de agendamentos</a></li>
              <li><a href="feedbackcoca.html">Feedback</a></li>
            </ul>
          </nav>

          <div class="header-btn">
            <a href="agendamento.html" class="visit-btn">Agende sua visita</a>
          </div>
        </div>
      </header>

      <!-- Cabeçalho da página -->
      <header class="site-header">
        <h1>Lembrete de visita</h1>
        <p>Organize sua visita com facilidade</p>
      </header>

      <main>
        <!-- Formulário -->
        <section class="form-section">
          <h2>Adicionar Lembrete</h2>

          <form id="remedioForm" onsubmit="validarFormulario(event)">
            <label for="nome">Atividade:</label>
            <input type="text" id="nome" name="nome" required>

            <label for="horario">Horário:</label>
            <input type="time" id="horario" name="horario" required>

            <label for="data">Data da visita:</label>
            <input type="date" id="data" name="data" required>

            <label for="duracao">Duração da atividade (em horas):</label>
            <input type="number" id="duracao" name="duracao" min="1" required>

            <button type="submit" class="btn">Ativar Lembrete</button>

            <p id="mensagemLembrete" class="mensagem" aria-live="polite"></p>
          </form>
        </section>
    </div>
    </section>
    </main>

    <!DOCTYPE html>
    <html lang="pt-BR">

    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Rodapé Coca-Cola</title>
      <link rel="stylesheet" href="cocarodape.css">
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    </head>

    <body>

      <footer class="footer">
        <div class="footer-container">
          <div class="footer-logo">
            <img src="https://upload.wikimedia.org/wikipedia/commons/c/ce/Coca-Cola_logo.svg" alt="Coca-Cola Logo">
            <p>Refrescando o mundo desde 1886</p>
          </div>

          <div class="footer-contact">
            <h3>Contato</h3>
            <p><strong>WhatsApp:</strong> <a href="https://wa.me/5511999999999" target="_blank">(11) 99999-9999</a></p>
            <p><strong>Email:</strong> <a href="mailto:contato@cocacola.com">contato@cocacola.com</a></p>
          </div>

          <div class="footer-social">
            <h3>Siga-nos</h3>
            <a href="https://instagram.com/cocacola" target="_blank">
              <img src="https://cdn-icons-png.flaticon.com/512/174/174855.png" alt="Instagram">
            </a>
            <a href="https://wa.me/5511999999999" target="_blank">
              <img src="https://cdn-icons-png.flaticon.com/512/733/733585.png" alt="WhatsApp">
            </a>
          </div>
        </div>

        <div class="footer-bottom">
          <p>© 2025 Coca-Cola Company - Todos os direitos reservados</p>
        </div>
      </footer>

  </div> <!-- .canvas -->
  </div> <!-- .page-bg -->

  <!-- Script de validação -->
  <script>
    function validarFormulario(event) {
      event.preventDefault();

      const nome = document.getElementById("nome").value.trim();
      const horario = document.getElementById("horario").value;
      const frequencia = Number(document.getElementById("frequencia").value);
      const duracao = Number(document.getElementById("duracao").value);
      const mensagem = document.getElementById("mensagemLembrete");

      if (!nome || !horario || frequencia < 1 || duracao < 1) {
        mensagem.textContent = "⚠️ Por favor, preencha todos os campos corretamente.";
        mensagem.style.color = "var(--danger)";
        return;
      }

      // comportamento de exemplo - substituir pela lógica real que desejar
      mensagem.style.color = "var(--success)";
      mensagem.textContent = "✅ Lembrete ativado! Redirecionando...";
      setTimeout(() => {
        window.location.href = "lembreteativado.html";
      }, 700);
    }
  </script>
</body>

</html>