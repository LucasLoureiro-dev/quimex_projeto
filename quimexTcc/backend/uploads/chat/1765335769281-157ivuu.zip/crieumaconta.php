<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome  = $_POST["nome"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];
    $confirmar = $_POST["confirmar"];

    // Verificar se as senhas batem
    if ($senha !== $confirmar) {
        $erro = "As senhas não coincidem!";
    } else {
        // Conectar ao banco
        $conn = new mysqli("localhost", "root", "", "cocacola_visitas");

        if ($conn->connect_error) {
            die("Erro na conexão: " . $conn->connect_error);
        }

        // Inserir no banco
        $sql = "INSERT INTO usuarios (nome, email, senha) VALUES ('$nome', '$email', '$senha')";

        if ($conn->query($sql) === TRUE) {
            $sucesso = "Conta criada com sucesso!";
        } else {
            $erro = "Erro ao cadastrar: " . $conn->error;
        }

        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro - Coca-Cola</title>
  <link rel="stylesheet" href="crieumaconta.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>

  <section class="login-section">
    <div class="login-container">
      <div class="login-logo">
        <img src="https://upload.wikimedia.org/wikipedia/commons/c/ce/Coca-Cola_logo.svg" alt="Coca-Cola Logo">
        <h2>Crie uma conta</h2>
      </div>

      <?php if (!empty($erro)) { ?>
        <p style="color:red; text-align:center;"><?php echo $erro; ?></p>
      <?php } ?>

      <?php if (!empty($sucesso)) { ?>
        <p style="color:green; text-align:center;"><?php echo $sucesso; ?></p>
      <?php } ?>

      <form class="login-form" action="" method="post">
        <div class="form-group">
          <label>Nome completo</label>
          <input type="text" name="nome" placeholder="Digite seu nome completo" required>
        </div>

        <div class="form-group">
          <label>E-mail</label>
          <input type="email" name="email" placeholder="Digite seu e-mail" required>
        </div>

        <div class="form-group">
          <label>Senha</label>
          <input type="password" name="senha" placeholder="Digite sua senha" required>
        </div>

        <div class="form-group">
          <label>Confirmar senha</label>
          <input type="password" name="confirmar" placeholder="Digite novamente sua senha" required>
        </div>

        <button type="submit" class="btn-login">Cadastrar</button>

        <p class="register-text">
          Já tem uma conta? <a href="login.php">Entrar</a>
        </p>
      </form>
    </div>
  </section>

</body>
</html>
