<?php
// ATIVAR ERROS (apenas para testar)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Variável para mensagem
$mensagemErro = "";

// Se enviou o formulário
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Conexão com o banco
   $con = new mysqli("localhost", "root", "", "cocacola");


    if ($con->connect_error) {
        die("Erro na conexão: " . $con->connect_error);
    }

    // Pegando dados
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Preparando consulta
   $stmt = $con->prepare("SELECT id, senha FROM usuarios WHERE email = ?");


    if (!$stmt) {
        die("Erro no prepare: " . $con->error);
    }

    $stmt->bind_param("s", $email);

    if (!$stmt->execute()) {
        die("Erro ao executar: " . $stmt->error);
    }

    $stmt->store_result();

    // Verificar se encontrou o usuário
    if ($stmt->num_rows > 0) {

        // Previne erro do editor marcando vermelho
        $id = null;
        $senhaHashDB = null;

        $stmt->bind_result($id, $senhaHashDB);
        $stmt->fetch();

        // Verificar a senha
      if (!empty($senhaHashDB) && password_verify($senha, $senhaHashDB)) {

            header("Location: painel.html");
            exit();
        } else {
            $mensagemErro = "Senha incorreta.";
        }

    } else {
        $mensagemErro = "E-mail não encontrado.";
    }

    $stmt->close();
    $con->close();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - Coca-Cola</title>
  <link rel="stylesheet" href="login.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>

  <section class="login-section">
    <div class="login-container">
      <div class="login-logo">
        <img src="https://upload.wikimedia.org/wikipedia/commons/c/ce/Coca-Cola_logo.svg" alt="Coca-Cola Logo">
        <h2>Bem-vindo de volta!</h2>
      </div>

      <!-- Mensagem de erro -->
      <?php if (!empty($mensagemErro)): ?>
        <p style="color:red; font-weight:600; text-align:center;"><?= htmlspecialchars($mensagemErro) ?></p>
      <?php endif; ?>

      <form class="login-form" action="" method="post">
        <div class="form-group">
          <label for="email">E-mail</label>
          <input type="email" id="email" name="email" placeholder="Digite seu e-mail" required>
        </div>

        <div class="form-group">
          <label for="senha">Senha</label>
          <input type="password" id="senha" name="senha" placeholder="Digite sua senha" required>
        </div>

        <div class="form-options">
          <label><input type="checkbox" name="lembrar"> Lembrar de mim</label>
          <a href="esqueciasenha.php">Esqueceu a senha?</a>
        </div>

       <button type="submit" class="btn-login">Entrar</button>

        <p class="register-text">
          Não tem uma conta? <a href="crieumaconta.php">Cadastre-se</a>
        </p>
      </form>
    </div>
  </section>

</body>
</html>
