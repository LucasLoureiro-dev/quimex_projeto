<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Esqueci minha senha - Coca-Cola</title>
  <link rel="stylesheet" href="esqueciasenha.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>

  <section class="login-section">
    <div class="login-container">
      <div class="login-logo">
        <img src="https://upload.wikimedia.org/wikipedia/commons/c/ce/Coca-Cola_logo.svg" alt="Coca-Cola Logo">
        <h2>Redefinir senha</h2>
      </div>

      <form class="login-form" action="#" method="post">

        <div class="form-group">
          <label for="email">E-mail cadastrado</label>
          <input type="email" id="email" name="email" placeholder="Digite seu e-mail" required>
        </div>

        <button type="submit" class="btn-login">Enviar código</button>

        <p class="register-text">
          Lembrou sua senha? <a href="login.html">Entrar</a>
        </p>
      </form>
    </div>
  </section>

</body>
</html>
