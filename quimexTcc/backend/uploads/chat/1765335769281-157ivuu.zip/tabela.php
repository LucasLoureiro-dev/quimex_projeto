<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Agendamentos</title>
    <link rel="stylesheet" href="tabela.css">
</head>
<body>

<body>
  <div class="page-bg">
    <div class="canvas">
      <header class="header">
        <div class="header-container">
          <div class="logo">
            <img src="https://upload.wikimedia.org/wikipedia/commons/c/ce/Coca-Cola_logo.svg" alt="Coca-Cola Logo">
          </div>

          <nav class="nav-menu">
            <ul>
              <li><a href="lembretecoca.php">Lembrete</a></li>
              <li><a href="tabela.php">Relatório de agendamentos</a></li>
              <li><a href="feedbackcoca.php">Feedback</a></li>
            </ul>
          </nav>

          <div class="header-btn">
            <a href="tabela.php" class="visit-btn">Agende sua visita</a>
          </div>
        </div>
      </header>

<section class="form-section">
    <h2>Novo Agendamento</h2>
    <form method="POST" action="">
        <label>Descrição</label>
        <input name="nome" required placeholder="Ex: Letícia Carvalho">

        <label>Horário</label>
        <input name="horario" required placeholder="Ex: 15:00">

        <label>Atividade</label>
        <input name="atividade" required placeholder="Ex: visita técnica">

        <label>Data</label>
        <input type="date" name="data" value="<?= date('Y-m-d') ?>">

        <label>Fornecedor CNPJ</label>
        <input name="cnpj" placeholder="00.000.000/0001-00">

        <button type="submit" name="salvar">Salvar</button>
    </form>
</section>

<!-- FILTROS -->
<section class="filters">
    <h2>Filtros de Relatório</h2>
    <form method="GET" class="form-filtros">
        <label>Cliente</label>
        <input type="text" name="cliente" placeholder="Nome do cliente">

        <label>De</label>
        <input type="date" name="inicio">

        <label>Até</label>
        <input type="date" name="fim">

        <button type="submit">Filtrar</button>
    </form>
</section>

<!-- LISTAGEM DO RELATÓRIO -->
<section class="tabela-section">
    <h2>Agendamentos</h2>

    <table class="tabela">
        <thead>
            <tr>
                <th>Descrição</th>
                <th>Horário</th>
                <th>Atividade</th>
                <th>Data</th>
                <th>CNPJ</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // EXEMPLO DE DADOS — troque por conexão ao banco
            $agendamentos = [
                ["Letícia Carvalho", "15:00", "Visita técnica", "2025-02-10", "00.000.000/0001-00"],
                ["João Silva", "09:00", "Reunião", "2025-02-12", "11.111.111/0001-11"],
            ];

            foreach ($agendamentos as $a): ?>
                <tr>
                    <td><?= htmlspecialchars($a[0]) ?></td>
                    <td><?= htmlspecialchars($a[1]) ?></td>
                    <td><?= htmlspecialchars($a[2]) ?></td>
                    <td><?= htmlspecialchars($a[3]) ?></td>
                    <td><?= htmlspecialchars($a[4]) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</section>

</body>
</html>
