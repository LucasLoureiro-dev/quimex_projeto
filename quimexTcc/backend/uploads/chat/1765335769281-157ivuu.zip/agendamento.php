<?php
// ATIVAR ERROS (apenas para testar)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Mensagem
$mensagem = "";

// SE o formulário for enviado
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Conectar ao banco
    $con = new mysqli("localhost", "usuario", "senha", "seu_banco");

    if ($con->connect_error) {
        die("Erro na conexão: " . $con->connect_error);
    }

    // Recebe os dados
    $nome = $_POST['nome'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];
    $idade = $_POST['idade'];
    $data_visita = $_POST['data_visita'];
    $horario = $_POST['horario'];
    $atividade = $_POST['atividade'];
    $duracao = $_POST['duracao'];
    $observacoes = $_POST['observacoes'];

    // Preparar SQL
    $stmt = $con->prepare("INSERT INTO agendamentos 
        (nome, telefone, email, idade, data_visita, horario, atividade, duracao, observacoes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );

    $stmt->bind_param(
        "sssisssss",
        $nome,
        $telefone,
        $email,
        $idade,
        $data_visita,
        $horario,
        $atividade,
        $duracao,
        $observacoes
    );

    if ($stmt->execute()) {
        $mensagem = "Agendamento realizado com sucesso! 🎉";
    } else {
        $mensagem = "Erro ao agendar: " . $stmt->error;
    }

    $stmt->close();
    $con->close();
}

?><!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agendamento - Fábrica Coca-Cola</title>
  <link rel="stylesheet" href="agendamento.css">
</head>

<header class="header">
    <div class="header-container">
      <div class="logo">
        <img src="https://upload.wikimedia.org/wikipedia/commons/c/ce/Coca-Cola_logo.svg" alt="Coca-Cola Logo">
      </div>

      <nav class="nav-menu">
        <ul>
          <li><a href="lembretecoca.php">Lembrete</a></li>
          <li><a href="agendamento,php">Relatório de agendamentos</a></li>
          <li><a href="feedbackcoca.php">Feedback</a></li>
        </ul>
      </nav>

      <div class="header-btn">
        <a href="lembretecoca.html" class="visit-btn">Agende sua visita</a>
      </div>
    </div>
  </header>

<body>
  <header>
    <h1>Agende sua Visita à Fábrica da Coca-Cola</h1>
    <p>Preencha suas informações e garanta uma experiência inesquecível!</p>
  </header>

  <main>
    <form class="form-agendamento">
      <h2>Formulário de Agendamento</h2>

      <!-- Dados pessoais -->
      <fieldset>
        <legend>Dados Pessoais</legend>
        <label for="nome">Nome completo:</label>
        <input type="text" id="nome" name="nome" placeholder="Digite seu nome" required>

        <label for="telefone">Telefone:</label>
        <input type="tel" id="telefone" name="telefone" placeholder="(XX) XXXXX-XXXX" required>

        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email" placeholder="exemplo@dominio.com" required>

        <label for="idade">Idade:</label>
        <input type="number" id="idade" name="idade" min="1" required>
      </fieldset>

      <!-- Dados da visita -->
      <fieldset>
        <legend>Informações da Visita</legend>

        <label for="data">Data da visita:</label>
        <input type="date" id="data" name="data" required>

        <label for="horario">Horário:</label>
        <select id="horario" name="horario" required>
          <option value="">Selecione um horário</option>
          <option>09:00</option>
          <option>13:00</option>
          <option>16:00</option>
          <option>19:00</option>
        </select>

        <label for="atividade">Atividade:</label>
        <select id="atividade" name="atividade" required>
          <option value="">Selecione uma atividade</option>
          <option>Tour guiado tradicional</option>
          <option>Degustação</option>
          <option>Mini Museu</option>
          <option>Crie sua própria bebida</option>
          <option>Visita técnica</option>
          <option>Área de Loja</option>
          <option>Sessão de fotos + lembrança</option>
          <option>Sala de experiência de marketing</option>
        </select>

        <label for="duracao">Duração:</label>
        <select id="duracao" name="duracao" required>
          <option value="">Selecione a duração</option>
          <option>30 minutos</option>
          <option>1 hora</option>
          <option>2 horas</option>
        </select>
      </fieldset>

      <!--  Mensagem de lembrete com link -->
      <p class="mensagem-lembrete">
        Não se esqueça de 
        <a href="lembretecoca.html" class="link-lembrete">
          adicionar o lembrete
        </a> 
        da sua visita para não perder o horário!
      </p>

      <!-- Observações -->
      <fieldset>
        <legend>Observações</legend>
        <textarea id="observacoes" name="observacoes" rows="4" placeholder="Escreva aqui informações adicionais (ex: número de visitantes, necessidades especiais, etc.)"></textarea>
      </fieldset>

      <button type="submit" class="botao-agendar">Agendar Visita</button>
    </form>
  </main>

  <!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rodapé Coca-Cola</title>
  <link rel="stylesheet" href="footer.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
</head>
<body>

  <footer class="footer">
    <div class="footer-container">
      <div class="footer-logo">
        <img src="https://upload.wikimedia.org/wikipedia/commons/c/ce/Coca-Cola_logo.svg" alt="Coca-Cola Logo">
        <p>Refrescando o mundo desde 1886</p>
      </div>

      <div class="footer-contact">
        <h3>Contato</h3>
        <p><strong>WhatsApp:</strong> <a href="https://wa.me/5511999999999" target="_blank">(11) 99999-9999</a></p>
        <p><strong>Email:</strong> <a href="mailto:contato@cocacola.com">contato@cocacola.com</a></p>
      </div>

      <div class="footer-social">
        <h3>Siga-nos</h3>
        <a href="https://instagram.com/cocacola" target="_blank">
          <img src="https://cdn-icons-png.flaticon.com/512/174/174855.png" alt="Instagram">
        </a>
        <a href="https://wa.me/5511999999999" target="_blank">
          <img src="https://cdn-icons-png.flaticon.com/512/733/733585.png" alt="WhatsApp">
        </a>
      </div>
    </div>

    <div class="footer-bottom">
      <p>©️ 2025 Coca-Cola Company - Todos os direitos reservados</p>
    </div>
  </footer>

</body>
</html>