<?php

$db_host = 'localhost';
$db_name = 'coca_agendamentos';
$db_user = 'root';
$db_pass = '';

$dsn = "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4";

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
];

try {
    $pdo = new PDO($dsn, $db_user, $db_pass, $options);
} catch (PDOException $e) {
    die("Erro ao conectar: " . $e->getMessage());
}


if (isset($_GET['api'])) {

    header('Content-Type: application/json; charset=utf-8');

    try {
        $stmt = $pdo->query("SELECT * FROM agendamentos ORDER BY data_visita ASC, horario ASC");
        $dados = $stmt->fetchAll();

        echo json_encode([
            "success" => true,
            "data" => $dados
        ]);
    } catch (Exception $e) {
        echo json_encode([
            "success" => false,
            "error" => "Erro ao buscar dados."
        ]);
    }

    exit; // impede carregar o HTML
}


?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Relatório de Agendamentos - Coca-Cola</title>
  <link rel="stylesheet" href="relatorio.css">
</head>

<body>

<header class="header">
    <div class="header-container">
      <div class="logo">
        <img src="https://upload.wikimedia.org/wikipedia/commons/c/ce/Coca-Cola_logo.svg" alt="Coca-Cola Logo">
      </div>

      <nav class="nav-menu">
        <ul>
          <li><a href="login.html">Login</a></li>
          <li><a href="lembretecoca.html">Lembrete</a></li>
          <li><a href="relatorio.php">Relatório de Agendamentos</a></li>
          <li><a href="feedbackcoca.html">Feedback</a></li>
        </ul>
      </nav>

      <div class="header-btn">
        <a href="agendamento.html" class="visit-btn">Agende sua visita</a>
      </div>
    </div>
</header>

<section class="titulo-relatorio">
    <h1>Relatório de Agendamentos</h1>
    <p>Acompanhe todos os visitantes que agendaram a experiência na Coca-Cola.</p>
</section>

<main class="conteudo">

  <div class="tabela-container">

    <table class="tabela-relatorio">
      <thead>
        <tr>
          <th>Nome</th>
          <th>Telefone</th>
          <th>E-mail</th>
          <th>Idade</th>
          <th>Data</th>
          <th>Horário</th>
          <th>Atividade</th>
          <th>Duração</th>
          <th>Observações</th>
        </tr>
      </thead>

      <tbody id="tbody-agendamentos">
        <tr>
          <td colspan="9" style="text-align:center; padding:20px;">Carregando...</td>
        </tr>
      </tbody>

    </table>

  </div>

</main>


<script>
async function carregarAgendamentos() {
    const tbody = document.getElementById("tbody-agendamentos");

    try {
        // chama a API dentro do MESMO arquivo
        const resposta = await fetch("RelatorioAgendamento.php?api=1");
        const json = await resposta.json();

        if (!json.success) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="9" style="text-align:center; padding:20px; color:red;">
                        Erro ao carregar dados.
                    </td>
                </tr>
            `;
            return;
        }

        const dados = json.data;

        if (dados.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="9" style="text-align:center; padding:20px;">
                        Nenhum agendamento encontrado.
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = "";

        dados.forEach(a => {
            tbody.innerHTML += `
                <tr>
                    <td>${a.nome}</td>
                    <td>${a.telefone}</td>
                    <td>${a.email}</td>
                    <td>${a.idade}</td>
                    <td>${formatarData(a.data_visita)}</td>
                    <td>${a.horario.substring(0,5)}</td>
                    <td>${a.atividade}</td>
                    <td>${a.duracao}</td>
                    <td>${a.observacoes || ""}</td>
                </tr>
            `;
        });

    } catch (e) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" style="text-align:center; padding:20px; color:red;">
                    Erro de conexão com o servidor.
                </td>
            </tr>
        `;
    }
}

function formatarData(data) {
    const [ano, mes, dia] = data.split("-");
    return `${dia}/${mes}/${ano}`;
}

carregarAgendamentos();
</script>

</body>
</html>