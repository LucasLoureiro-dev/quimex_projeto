<?php
// Mostrar erros (apenas em desenvolvimento)
ini_set('display_errors', 1);
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Config DB — adapte aqui suas credenciais
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'cocacola';

// Conectar com charset
try {
    $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
    $conn->set_charset('utf8mb4');
} catch (Exception $e) {
    // Erro grave de conexão
    die("Erro de conexão com o banco: " . htmlspecialchars($e->getMessage()));
}

$mensagemResposta = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recebe e valida (simples)
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mensagem = trim($_POST['mensagem'] ?? '');

    if ($nome === '' || $email === '' || $mensagem === '') {
        $mensagemResposta = "⚠️ Preencha todos os campos.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensagemResposta = "⚠️ E-mail inválido.";
    } else {
        // Inserção segura com prepared statement
        $sql = "INSERT INTO feedback (nome, email, mensagem) VALUES (?, ?, ?)";
        try {
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('sss', $nome, $email, $mensagem);
            $stmt->execute();
            $stmt->close();
            $mensagemResposta = "✅ Obrigado pelo seu feedback, " . htmlspecialchars($nome) . "!";
        } catch (Exception $e) {
            $mensagemResposta = "❌ Erro ao salvar feedback: " . htmlspecialchars($e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Feedback - Fábrica Coca-Cola</title>
  <link rel="stylesheet" href="feedbackcoca.css">
</head>
<body>
  <div class="page-bg">
    <div class="canvas">
      <!-- header (omitido aqui por brevidade, mantenha o seu) -->
      <main>
        <section class="site-header">
          <h1>Deixe seu Feedback</h1>
          <p>Sua opinião nos ajuda a melhorar cada vez mais!</p>
        </section>

        <section class="form-section">
          <h2>Envie seu comentário</h2>

          <form method="POST" action="feedback.php" id="feedbackForm">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" placeholder="Digite seu nome" required>

            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" placeholder="Digite seu e-mail" required>

            <label for="mensagem">Mensagem:</label>
            <textarea id="mensagem" name="mensagem" rows="5" placeholder="Digite seu feedback aqui..." required></textarea>

            <button type="submit">Enviar Feedback</button>
          </form>

          <p class="mensagem"><?php echo $mensagemResposta; ?></p>
        </section>
      </main>

      <!-- footer (mantenha o seu) -->

    </div>
  </div>
</body>
</html>
